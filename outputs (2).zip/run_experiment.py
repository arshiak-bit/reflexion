"""Run Reflexion (programming_runs/main.py) on a seeded random subset of HumanEval-Python.

Usage (from the cloned repo's programming_runs/ folder):
    python ../run_experiment.py --strategy reflexion --seed 0 --n 30 --model gpt-3.5-turbo

The authors' main.py has no subset or seed option, so this wrapper (a) writes a seeded random
subset of the benchmark to a new .jsonl and (b) calls main.py exactly as run_reflexion.sh does.
Full console output is saved to logs/.
"""
import argparse, glob, json, os, random, subprocess, sys, time

p = argparse.ArgumentParser()
p.add_argument("--strategy", choices=["simple", "reflexion"], required=True)
p.add_argument("--seed", type=int, default=0)
p.add_argument("--n", type=int, default=30, help="number of HumanEval problems in the subset")
p.add_argument("--model", default="gpt-3.5-turbo")
p.add_argument("--max_iters", default="2")
p.add_argument("--dataset", default=None, help="path to humaneval-py.jsonl (auto-detected if omitted)")
p.add_argument("--logs_dir", default="../logs")
a = p.parse_args()

ds = a.dataset or next(iter(sorted(glob.glob("benchmarks/humaneval-py*.jsonl"))), None)
if ds is None or not os.path.exists(ds):
    sys.exit("Could not find benchmarks/humaneval-py*.jsonl; pass --dataset")
rows = [l for l in open(ds) if l.strip()]
random.seed(a.seed)
subset = random.sample(rows, min(a.n, len(rows)))
os.makedirs("subsets", exist_ok=True)
sub_path = f"subsets/humaneval_py_n{a.n}_seed{a.seed}.jsonl"
open(sub_path, "w").writelines(subset)

run_name = f"{a.strategy}_humaneval_py_n{a.n}_seed{a.seed}"
cmd = [sys.executable, "main.py", "--run_name", run_name, "--root_dir", "root",
       "--dataset_path", sub_path, "--strategy", a.strategy, "--language", "py",
       "--model", a.model, "--pass_at_k", "1", "--max_iters", str(a.max_iters), "--verbose"]
os.makedirs(a.logs_dir, exist_ok=True)
log_path = os.path.join(a.logs_dir, f"{run_name}.log")
print("Running:", " ".join(cmd), flush=True)
t0 = time.time()
with open(log_path, "w") as log:
    log.write("CMD: " + " ".join(cmd) + "\n")
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    for line in proc.stdout:
        sys.stdout.write(line); log.write(line)
    proc.wait()
    log.write(f"\nEXIT CODE {proc.returncode}; wall time {time.time()-t0:.0f}s\n")
sys.exit(proc.returncode)
