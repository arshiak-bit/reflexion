"""Collect pass@1 per run from the authors' log files into a CSV.

Run from programming_runs/:  python ../parse_results.py root ../results/my_results.csv 30
Third argument (optional) = N: only runs made with that subset size are kept (skips smoke tests).
Counts one record per problem (last record wins) and reads its `is_solved` field.
Runs with no scored problems are SKIPPED (never filled with zeros) and reported.
"""
import csv, glob, json, os, re, sys

SOLVED_KEYS = ("is_solved", "solved")
ID_KEYS = ("task_id", "name", "prompt")
root = sys.argv[1] if len(sys.argv) > 1 else "root"
out = sys.argv[2] if len(sys.argv) > 2 else "../results/my_results.csv"
only_n = int(sys.argv[3]) if len(sys.argv) > 3 else None
rows, skipped = [], []
for d in sorted(glob.glob(os.path.join(root, "*_humaneval_py_n*_seed*"))):
    m = re.match(r"(simple|reflexion)_humaneval_py_n(\d+)_seed(\d+)$", os.path.basename(d))
    if not m:
        continue
    strat, n, seed = m.group(1), int(m.group(2)), int(m.group(3))
    if only_n is not None and n != only_n:
        continue
    per_problem = {}
    for f in glob.glob(os.path.join(d, "**", "*.jsonl"), recursive=True):
        for line in open(f):
            line = line.strip()
            if not line:
                continue
            try:
                r = json.loads(line)
            except ValueError:
                continue
            key = next((str(r[k]) for k in ID_KEYS if k in r), None)
            sol = next((r[k] for k in SOLVED_KEYS if k in r), None)
            if key is not None and sol is not None:
                per_problem[key] = bool(sol)
    if not per_problem:
        skipped.append(os.path.basename(d)); continue
    solved, total = sum(per_problem.values()), len(per_problem)
    rows.append(dict(strategy=strat, seed=seed, n_requested=n, n_scored=total, solved=solved,
                     pass_at_1=round(solved / total, 4)))
if skipped:
    print("WARNING: no scored problems found (run failed?) for:", skipped)
if not rows:
    sys.exit("ERROR: no results found. Look at logs/*.log to see why the runs failed.")
os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
with open(out, "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=["strategy", "seed", "n_requested", "n_scored", "solved", "pass_at_1"])
    w.writeheader(); w.writerows(rows)
print(open(out).read())
