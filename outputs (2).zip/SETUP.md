# SETUP
- Date: 2026-11-09
- Python: 3.13.18
- OS / runtime: Linux-6.6.159+-x86_64-with-glibc2.39 (Google Colab)
- GPU: none (CPU runtime) (not used: the LLM runs via the OpenAI API)
- Model: gpt-4o-mini; subset N=30; seeds=[0, 1, 2]; max_iters=2
- Packages: see requirements.txt (pip freeze, Colab-only packages removed)
