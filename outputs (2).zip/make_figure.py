"""Draw fig1.pdf from results/my_results.csv: paper vs. my pass@1 (mean +/- std over seeds)."""
import csv, statistics as st
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

PAPER = {"simple": 0.80, "reflexion": 0.91}   # Reflexion paper, Table 2, HumanEval (PY), GPT-4
LABEL = {"simple": "Base (single sample)", "reflexion": "Reflexion"}
data = {"simple": [], "reflexion": []}
for r in csv.DictReader(open("results/my_results.csv")):
    if r["pass_at_1"] != "":
        data[r["strategy"]].append(float(r["pass_at_1"]))

plt.rcParams.update({"font.size": 8, "font.family": "serif", "axes.labelsize": 8,
                     "legend.fontsize": 7, "xtick.labelsize": 8, "ytick.labelsize": 8})
fig, ax = plt.subplots(figsize=(3.5, 2.4))
x = range(2)
w = 0.36
paper = [PAPER["simple"], PAPER["reflexion"]]
mine = [st.mean(data[s]) if data[s] else 0 for s in ("simple", "reflexion")]
err = [st.stdev(data[s]) if len(data[s]) > 1 else 0 for s in ("simple", "reflexion")]
# Okabe-Ito colours + hatching so it stays readable in grayscale
ax.bar([i - w/2 for i in x], paper, w, color="#0072B2", hatch="//", edgecolor="black", label="Paper (GPT-4)")
ax.bar([i + w/2 for i in x], mine, w, yerr=err, capsize=3, color="#E69F00", hatch="..", edgecolor="black",
       label="This work (mean $\\pm$ std, 3 seeds)")
ax.set_xticks(list(x)); ax.set_xticklabels([LABEL["simple"], LABEL["reflexion"]])
ax.set_ylabel("Pass@1 accuracy (fraction)"); ax.set_xlabel("Method")
ax.set_ylim(0, 1.15); ax.legend(loc="upper left", frameon=False)
plt.savefig("fig1.pdf", bbox_inches="tight")
print("saved fig1.pdf")
