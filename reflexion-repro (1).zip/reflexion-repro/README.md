# Reproducing Reflexion on HumanEval (Python)

## Overview
Reproduction of one result from **Reflexion: Language Agents with Verbal Reinforcement Learning**
(Shinn, Cassano, Berman, Gopinath, Narasimhan, Yao; NeurIPS 2023), DOI [10.48550/arXiv.2303.11366](https://doi.org/10.48550/arXiv.2303.11366).
Original repository: https://github.com/noahshinn024/reflexion (MIT licence, kept in `LICENSE`).
This fork adds a run wrapper, log parser, results, figure script and notes. The authors' code is unchanged.

Reproduced: **Table 2, HumanEval (PY) pass@1** (paper: base 0.80, Reflexion 0.91 with GPT-4).

## Setup
1. Open `reflexion_repro.ipynb` in Google Colab (free runtime is enough; the LLM is called through the OpenAI API, so no GPU is needed).
2. Set `FORK_URL` in the first code cell to this repository.
3. You need an OpenAI API key. A full run (2 strategies x 3 seeds x 30 problems) is a small number of API calls; check current pricing.

Local alternative:
```bash
git clone https://github.com/<YOUR_GITHUB_USERNAME>/reflexion && cd reflexion/programming_runs
python -m venv env && source env/bin/activate
pip install -r requirements.txt
export OPENAI_API_KEY=<your key>
```
Exact versions used are in `requirements.txt`; machine details are in `SETUP.md`.

## How to run
```bash
cd programming_runs
for seed in 0 1 2; do
  python run_experiment.py --strategy simple    --seed $seed --n 30 --model gpt-3.5-turbo
  python run_experiment.py --strategy reflexion --seed $seed --n 30 --model gpt-3.5-turbo
done
python parse_results.py root results/my_results.csv
python make_figure.py
```
`run_experiment.py` samples a random subset of HumanEval-Python with the given seed and calls the authors' `main.py` exactly as their `run_reflexion.sh` does. Do not run generated code on a machine you care about: the authors warn it is not sandboxed. Colab is a safe place for it.

## Expected output
- `logs/`: full console output for every run.
- `results/my_results.csv`: pass@1 per strategy and seed.
- `fig1.pdf`: paper value next to mine (mean and standard deviation over 3 seeds).

## Differences from the paper
- Subset of N problems instead of all 164 (see `NOTES.md` and the report for the exact N).
- A cheaper model than GPT-4, because of access and cost.
- Seeds control which problems are sampled; the OpenAI API itself is not seedable, so runs on the same subset can still differ.
- Outcome and the reasons are in the report and `NOTES.md`.

## Citation
See `CITATION.cff`. Please also cite the original paper (`arXiv:2303.11366`).
