# NOTES: every attempt, including failures (do not delete failed attempts)

| # | What I tried | Error / observation | Outcome |
|---|--------------|---------------------|---------|
| 1 | Ran the README / `run_reflexion.sh` command as written | (paste the error) | |
| 2 | | | |
| 3 | | | |

## What I reduced
- Problems: N of 164
- Model: 
- Seeds: 0, 1, 2 (subset sampling)
