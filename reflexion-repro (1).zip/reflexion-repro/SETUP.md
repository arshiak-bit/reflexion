# SETUP
(Overwritten automatically by step 2 of `reflexion_repro.ipynb`; fill in by hand if you run locally.)
- Date:
- Python:
- OS / runtime:
- GPU:
- Model / N / seeds:
- Packages: see requirements.txt (`pip freeze > requirements.txt`)
