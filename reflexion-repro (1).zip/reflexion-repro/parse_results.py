"""Collect pass@1 per run from the authors' log files into results/my_results.csv.

Counts one record per problem (last record wins) and reads its `is_solved` field.
CHECK the first run by eye against the log: if your copy of the repo names the field
differently, adjust SOLVED_KEYS below.
"""
import csv, glob, json, os, re, sys

SOLVED_KEYS = ("is_solved", "solved")
ID_KEYS = ("task_id", "name", "prompt")
root = sys.argv[1] if len(sys.argv) > 1 else "root"
out = sys.argv[2] if len(sys.argv) > 2 else "results/my_results.csv"
rows = []
for d in sorted(glob.glob(os.path.join(root, "*_humaneval_py_n*_seed*"))):
    m = re.match(r"(simple|reflexion)_humaneval_py_n(\d+)_seed(\d+)", os.path.basename(d))
    if not m:
        continue
    strat, n, seed = m.group(1), int(m.group(2)), int(m.group(3))
    per_problem = {}
    for f in glob.glob(os.path.join(d, "**", "*.jsonl"), recursive=True):
        for line in open(f):
            line = line.strip()
            if not line:
                continue
            r = json.loads(line)
            key = next((str(r[k]) for k in ID_KEYS if k in r), None)
            sol = next((r[k] for k in SOLVED_KEYS if k in r), None)
            if key is not None and sol is not None:
                per_problem[key] = bool(sol)
    solved = sum(per_problem.values())
    total = len(per_problem)
    rows.append(dict(strategy=strat, seed=seed, n_requested=n, n_scored=total, solved=solved,
                     pass_at_1=round(solved / total, 4) if total else ""))
os.makedirs(os.path.dirname(out), exist_ok=True)
with open(out, "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=["strategy", "seed", "n_requested", "n_scored", "solved", "pass_at_1"])
    w.writeheader(); w.writerows(rows)
print(open(out).read())
